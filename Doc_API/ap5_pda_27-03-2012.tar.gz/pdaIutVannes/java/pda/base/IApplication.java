/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.base;

import pda.base.IPda;
import javax.swing.*;

/**
 *  Common interface for all plugable applications.
 *
 * @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 * @version $Revision: 27 $
 * @date $Date: 2009-03-08 19:04:18 +0100 (dim 08 mar 2009) $
 * 
 */
public interface IApplication {
    
    /**
     *  Start the application in the specified PDA
     */
    public void start(IPda pda);
    
    /**
     *  Return the application name as String
     */
    public String getAppliName();
    
    /**
     *  Return the panel that contains all the application display
     */
    public JPanel getAppliPanel();
    
    /**
     *  Clode the application ant its display panel
     * @param false if the application denied to commit a suicide
     */
    public boolean close();
    
} // --------------------------------------------------- Interface IApplication
