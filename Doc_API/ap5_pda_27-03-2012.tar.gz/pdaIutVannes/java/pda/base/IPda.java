/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.base;

import javax.swing.ImageIcon;
import java.awt.Point;
import java.util.Vector;

import pda.base.IApplication;

/**
 *  Minimal interface of a PDA.
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 27 $
 */
public interface IPda {

    /**
     *  Launch the specified application
     */
    public void launchAppli(IApplication appli);

    /**
     * Change PDA look
     * @param skin background image
     * @param pos screen position on skin
     */
    public void setSkin (ImageIcon skin, Point pos);

    /**
     * Get names of application already launch
     * @return names
     */
    public Vector<String> getApplicationsName ();

    /**
     * Set application foreground
     * @param name of the chosen application
     */
    public void selectApplication (String name);

    /**
     * Kill an application
     * @param appli application reference
     */
    public void exitApplication (IApplication appli);

} // ----------------------------------------------------------- Interface IPda
