/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.base;

import pda.base.IApplication;
import pda.base.IPda;
import pda.launcher.Launcher;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/** 
 *  The base class of PDA simulator.
 *
 *  This class displays the PDA emulator and manage all the applications
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 27 $
 */
public class PdaEngine {
    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constructors
     */
    
    /**
     *  The PDASimu constructor.
     */
    public PdaEngine() {
    } // ------------------------------------------------------------ PDASimu()
    
    /*
     *  Public methods
     */
    

    /* 
     *  see interface documentation
     */
    public void launchAppli(IApplication appli) {
	startedApplications.add(appli);
    } // -------------------------------------------------------- launchAppli()


    /**
     *  Close the current application
     */
    public void closeAppli(int idx) {
	IApplication appli = startedApplications.elementAt(idx) ;
	exitApplication (appli);
    } // --------------------------------------------------------- closeAppli()


    public Vector<String> getApplicationsName () {
	Vector<String> result = new Vector<String> ();
	for (IApplication appli : startedApplications)
	    result.add (appli.getAppliName ());
	return result;
    }

    public JPanel getApplicationPanel (String name) {
	for (IApplication appli : startedApplications) {
	    if (name.equals (appli.getAppliName ())) {
		return appli.getAppliPanel ();
	    }
	}
	return null;
    }

    public void exitApplication (IApplication appli) {
	startedApplications.remove (appli);
    }

    /*
     * Private implementation -------------------------------------------------
     */
        
    /** the vector that stores the running applications */
    protected Vector<IApplication> startedApplications = 
                                                    new Vector<IApplication>();

} // ------------------------------------------------------------ Class PDASimu
