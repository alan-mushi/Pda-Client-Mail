/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.base;

import pda.base.IApplication;
import pda.base.IPda;
import pda.launcher.Launcher;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/** 
 *  The base class of PDA simulator.
 *
 *  This class displays the PDA emulator and manage all the applications
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 32 $
 */
public class PdaScreen extends JFrame {
    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constants
     */
    
    /** X position of the screen's left corner */
    public static final int screenX = 22;
    
    /** Y position of the screen's left corner */
    public static final int screenY = 78;
    
    /** width of the screen */
    public static final int screenW = 322;
    
    /** height of the screen */
    public static final int screenH = 346;

    /*
     *  Constructors
     */
    
    /**
     *  The PDASimu constructor.
     */
    public PdaScreen(PdaEngine anEngine, PdaSimu aPda) {
	super(" PDA Simu ");
        engine = anEngine;
        ctrl = aPda;
	guiInit();
    } // ---------------------------------------------------------- PdaScreen()
    
    /*
     *  Public methods
     */
    


    /* 
     *  see interface documentation
     */
    public void addAppli(String appliName, JPanel appliPanel) {
        System.out.println("Add panel for " + appliName);
	tabbedPane.addTab(appliName, null, appliPanel, appliName);
	tabbedPane.setSelectedIndex (tabbedPane.getTabCount ()-1);
    } // ----------------------------------------------------------- addAppli()
    
    /**
     *  Return the index of the selected application.
     *
     * @return the required index
     */
    public int getAppliIndex() {
       return tabbedPane.getSelectedIndex(); 
    } // ------------------------------------------------------ getAppliIndex()

    public int getAppliIndex (JPanel appliPanel) {
	return  tabbedPane.indexOfComponent(appliPanel);
    }

    /**
     *  Close the current application
     */
    public void closeAppli(int idx) {
	tabbedPane.removeTabAt(idx);
    } // --------------------------------------------------------- closeAppli()

    /**
     *  Quit the PDA program
     */
    // Attention pas de synchronized sinon le thread de la machine virtuelle qui gère l'IHM se cloque
    public void quit() {
	if ( JOptionPane.showConfirmDialog(this,
	        "Voulez-vous vraiment quitter ?",
		"Fermeture du programme",
		JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION ) {
	    System.exit(0);
	}
    } // --------------------------------------------------------------- quit()

    public void selectApplication (JPanel appliPanel) {
	if (appliPanel != null)
	    tabbedPane.setSelectedComponent (appliPanel);
    }

    /*
     * Private implementation -------------------------------------------------
     */
    
    /**
     *  Initialization of the GUI
     */
    protected void guiInit() {
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    quit();
		}
	    });
	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	JMenuBar menubar = new JMenuBar();
	menubar.setLayout(new BoxLayout(menubar, BoxLayout.X_AXIS));
	menubar.add(fileMenu);
	menubar.add(Box.createHorizontalGlue());
	menubar.add(helpMenu);
	setJMenuBar(menubar);

	fileMenu.add(startMI);
	fileMenu.add(closeMI);
	fileMenu.add(quitMI);

	startMI.addActionListener(ctrl);
	closeMI.addActionListener(ctrl);
	quitMI.addActionListener(ctrl);

	JLayeredPane layeredPane = new JLayeredPane();
	skin = new JLabel ();
	skin.setLocation (0, 0);
	layeredPane.add (skin, new Integer(0));
	layeredPane.add (tabbedPane, new Integer(5));
	tabbedPane.setSize (screenW, screenH);

	setSkin (new ImageIcon ("data/img/palm.png"), new Point (screenX, screenY));

	getContentPane().add(layeredPane, BorderLayout.CENTER);

	pack();
	setVisible(true);
    } // ------------------------------------------------------------ guiInit()
    
    
    public void setSkin (ImageIcon skinIcon, Point pos) {
	tabbedPane.setLocation (pos);

	skin.setIcon (skinIcon);
	int width = skinIcon.getIconWidth();
	int height = skinIcon.getIconHeight();
	skin.setSize(width, height);
	skin.getParent ().setPreferredSize(new Dimension(width, height));
    }

    /** Class is serializable, it must define a serial version */
    protected static final long serialVersionUID = 0L;

    /** file menu item */
    protected JMenu fileMenu = new JMenu("File");
    
    /** help menu item */
    protected JMenu helpMenu = new JMenu("Help");

    /** start menu item */
    protected JMenuItem startMI = new JMenuItem("start Launcher");
    
    /** close menu item */
    protected JMenuItem closeMI = new JMenuItem("close application");
    
    /** quit menu item */
    protected JMenuItem quitMI = new JMenuItem("quit");

    /** the skin ot the application */
    protected JLabel skin;

    /** the tabbed pane */
    protected JTabbedPane tabbedPane = new JTabbedPane();
    
    /** the view of the application */
    protected PdaSimu ctrl;
    
    /** the engine of the application */
    protected PdaEngine engine;
    
} // ------------------------------------------------------------ Class PDASimu
