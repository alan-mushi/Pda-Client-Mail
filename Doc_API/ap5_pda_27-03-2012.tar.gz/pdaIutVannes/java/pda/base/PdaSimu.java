/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.base;

import pda.base.IApplication;
import pda.base.IPda;
import pda.launcher.Launcher;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/** 
 *  The base class of PDA simulator.
 *
 *  This class displays the PDA emulator and manage all the applications
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 27 $
 */
public class PdaSimu implements pda.base.IPda, ActionListener {
    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constants
     */
    
    /** X position of the screen's left corner */
    public static final int screenX = 25;
    
    /** Y position of the screen's left corner */
    public static final int screenY = 130;
    
    /** width of the screen */
    public static final int screenW = 326;
    
    /** height of the screen */
    public static final int screenH = 326;

    /*
     *  Constructors
     */
    
    /**
     *  The PDASimu constructor.
     */
    public PdaSimu() {
        engine = new PdaEngine();
        view = new PdaScreen(engine, this);
        startLauncher();
    } // ------------------------------------------------------------ PDASimu()
    
    /*
     *  Public methods
     */
    
    /**
     *  The launcher of the PDA program.
     */
    public static void main(String [] arg) {
	new pda.base.PdaSimu();
    } // --------------------------------------------------------------- main()



    /* 
     *  see interface documentation
     */
    public void launchAppli(IApplication appli) {
        view.addAppli(appli.getAppliName(), appli.getAppliPanel());
	engine.launchAppli(appli);
        appli.start(this);
    } // -------------------------------------------------------- launchAppli()


    /**
     *  see interface documentation
     */
    public Vector<String> getApplicationsName () {
	return engine.getApplicationsName ();
    }

    /**
     *  see interface documentation
     */
    public void selectApplication (String name) {
	view.selectApplication (engine.getApplicationPanel (name));
    }

    /**
     *  see interface documentation
     */
    public void exitApplication (IApplication appli) {
	if (appli == null)
	    return;
	if (!appli.close ())
	    return;
	int idx = view.getAppliIndex(appli.getAppliPanel ());
	if(idx < 0) {
	    return;
        }
        view.closeAppli(idx);
        engine.closeAppli(idx);
    }

    /* 
     *  see interface documentation
     * XXX ImageIcon ou URL ?
     */
    public void setSkin (ImageIcon skinIcon, Point pos) {
	view.setSkin (skinIcon, pos);
    }

    /**
     *  Start the lancher application
     */
    public void startLauncher() {
	IApplication launcher = new Launcher();
	launchAppli(launcher);
    } // ------------------------------------------------------ startLauncher()

    /**
     *  Close the current application
     */
    public void closeAppli() {
	int idx = view.getAppliIndex();
	if(idx < 0) {
	    return;
        }
        engine.closeAppli(idx);
        view.closeAppli(idx);
    } // --------------------------------------------------------- closeAppli()

    /**
     *  Quit the PDA program
     */
    public synchronized void quit() {
        view.quit();
    } // --------------------------------------------------------------- quit()

    /**
     *  Callback function, reaction to button pushed.
     */
    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if(source == view.quitMI)
	    quit();
	else if(source == view.startMI)
	    startLauncher();
	else if(source == view.closeMI)
	    closeAppli();
    } // ---------------------------------------------------- actionPerformed()

    /*
     * Private implementation -------------------------------------------------
     */
    
    /** the view of the application */
    protected PdaScreen view;
    
    /** the engine of the application */
    protected PdaEngine engine;

} // ------------------------------------------------------------ Class PDASimu
