/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.helloworld;

/**
 *  The simplest application in the PDA.
 *
 *  It can be used to construct other applications.
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 2 $
 */
public class HWEngine {
    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Public methods
     */
    
    /**
     *  Get the text of the application
     *
     * @return the text of the application
     */
    public String getLabel() {
        return label;        
    }

    /*
     * Private implementation -------------------------------------------------
     */
    
    /** the name of the application */
    protected String label = "Bonjour le monde";
    
 
} // ---------------------------------------------------------- Class HelloWorld
