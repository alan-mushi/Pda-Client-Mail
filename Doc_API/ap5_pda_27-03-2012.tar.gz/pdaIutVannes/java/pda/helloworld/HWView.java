/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.helloworld;

import pda.helloworld.HWEngine;
import javax.swing.*;

/**
 *  The simplest application in the PDA.
 *
 *  It can be used to construct other applications.
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 2 $
 */
public class HWView {
    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constructors
     */

    /**
     *  The HWView constructor
     *
     * @param anEngine the that is transmitted by the controller
     */
    public HWView(HWEngine anEngine) {
        engine = anEngine;
    } // ------------------------------------------------------------- HWView()

    /*
     *  Public methods
     */
    
    /* 
     *  see interface documentation
     */
    public void initLabel() {
	panel.add(new JLabel(engine.getLabel()));
    } // ---------------------------------------------------------- initLabel()

    /** 
     *  Get the main panel
     *
     * @return the main panel of the application
     */
    public JPanel getPanel() {
	return panel;
    } // ----------------------------------------------------------- getPanel()

    /*
     * Private implementation -------------------------------------------------
     */
    
    /** the engine of the application */
    protected HWEngine engine;
    
    /** the pane owned by the application */
    protected JPanel panel = new JPanel();

} // ------------------------------------------------------------- Class HWView
