/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.helloworld;

import pda.base.IApplication;
import pda.base.IPda;
//import java.awt.*;
//import java.awt.event.*;
import javax.swing.*;

/**
 *  The simplest application in the PDA.
 *
 *  It can be used to construct other applications.
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 27 $
 */
public class HelloWorld implements IApplication {
    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constructors
     */

    /**
     *  The helloworld constructor
     */
    public HelloWorld() {
        engine = new HWEngine();
        view = new HWView(engine);
    } // --------------------------------------------------------- HelloWorld()

    /*
     *  Public methods
     */
    
    /* 
     *  see interface documentation
     */
    public void start(IPda pda) {
        view.initLabel();
    } // -------------------------------------------------------------- start()

    /* 
     *  see interface documentation
     */
    public String getAppliName() {
	return name;
    } // ---------------------------------------------------------- helloworld()

    /* 
     *  see interface documentation
     */
    public JPanel getAppliPanel() {
	return view.getPanel();
    } // ---------------------------------------------------------- helloworld()

    /* 
     *  see interface documentation
     */
    public boolean close() {
	return true;
    } // ---------------------------------------------------------- helloworld()

    /*
     * Private implementation -------------------------------------------------
     */
    
    /** the name of the application */
    protected String name = "Hello";
    
    /** the view of the application */
    protected HWView view;
    
    /** the engine of the application */
    protected HWEngine engine;

} // ---------------------------------------------------------- Class HelloWorld
