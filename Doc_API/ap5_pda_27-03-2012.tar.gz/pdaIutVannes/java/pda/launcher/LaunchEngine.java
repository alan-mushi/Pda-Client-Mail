/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.launcher;

import pda.base.IApplication;
import pda.helloworld.HelloWorld;
import pda.launcher.Launcher;

import java.util.Hashtable;

/**
 *  The "LaunchEngine application that starts all others
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 31 $
 */
public class LaunchEngine {

    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constructors
     */
    
    /** 
     *  LaunchEngine constructor.
     *
     *  Initialize applications collection and the panel
     */
    public LaunchEngine() {
        appArray[0] = "hello";
	applications.put("hello", HelloWorld.class);
        icons.put("hello", "hello.png");
        appArray[1] = "launcher";
	applications.put("launcher", Launcher.class);
        icons.put("launcher", "launcher.png");

    } // ------------------------------------------------------- LaunchEngine()

    /*
     * Public methods
     */

    /**
     *  Get the applications count
     *
     * @return the number of declared applications
     */
    public int appCount() {
        return appArray.length;
    }
    
    /**
     *  Get the application name at index i.
     *
     * @param i : then index of the application
     * @return the application name
     */
    public String appKeyAt(int i) {
        return appArray[i];
    }
    
    /**
     *  Get an application instance
     *
     * @param appName : name of the application to get
     * @return an instance of the required application, null if not ok
     */
    public IApplication getAppli(String appName) {
        IApplication ret;
        
        try {
            ret = (IApplication) applications.get(appName).newInstance();
	} catch(InstantiationException e2) {
	    System.out.println("InstantiationException");
            ret = null;
	} catch(IllegalAccessException e2) {
	    System.out.println("IllegalAccessException");
	    // YYY message
            ret = null;
	}
        return ret;
    } // ----------------------------------------------------------- getAppli()

    /** 
     *  Get the icon filename of an application.
     *
     * @param appName : name of the application
     * @return the full name of the icon file
     */
    public String getIcon(String appName) {
        String ret;
            ret = "./data/img/" + icons.get(appName);
        return ret;
    }
    
    /*
     * Private implementation -------------------------------------------------
     */
    
    /** The array of application names */
    protected String[] appArray = new String[12];
    
    /** The list of application classes that can be launched */
    protected Hashtable<String, Class> applications = 
                                                new Hashtable<String, Class>();
    
    /** The list of icons associated to applications */
    protected Hashtable<String, String> icons = new Hashtable<String, String>();

} // ----------------------------------------------------------- Class LaunchEngine
