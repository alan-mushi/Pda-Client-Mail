/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.launcher;

import pda.base.IApplication;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 *  The "LaunchView application that starts all others
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 29 $
 */
public class LaunchView {

    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constructors
     */
    
    /** 
     *  LaunchView constructor.
     *
     *  Initialize applications collection and the panel
     */
    public LaunchView(Launcher ctrl, LaunchEngine theEngine) {
        JButton btn;
        engine = theEngine;
        
	for(int i = 0; i < engine.appCount(); i++) {
            String apn = engine.appKeyAt(i);
            if ( apn != null ) {
                System.out.println(apn);
                btn = new JButton(apn, new ImageIcon(engine.getIcon(apn)));
                panel.add(btn);
                btn.addActionListener(ctrl);
            }
	}
    } // --------------------------------------------------------- LaunchView()

    /*
     * Public methods
     */
    
    /* 
     *  see interface documentation
     */
    public JPanel getPanel() {
	return panel;
    } // ------------------------------------------------------ getAppliPanel()
    
    /*
     * Private implementation -------------------------------------------------
     */
    
    /** The panel associated to the LaunchView */
    protected JPanel panel = new JPanel(new GridLayout(4, 3));

    /** the engine of the application */
    protected LaunchEngine engine;

} // ----------------------------------------------------------- Class LaunchView
