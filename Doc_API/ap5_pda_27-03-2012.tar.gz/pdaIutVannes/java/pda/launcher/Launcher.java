/* 
 *  PDA project -- UBS/IUT de Vannes -- Dept Informatique
 *
 *  $Id$
 *
 *  Copyright 2007-08 © IUT de Vannes
 *  Ce logiciel pédagogique est diffusé sous licence GPL
 */
package pda.launcher;

import pda.base.IPda;
import pda.base.IApplication;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 *  The "launcher application that starts all others
 *
 *  @author F. Merciol, D. Deveaux 
 *                      <{francois.merciol|daniel.deveaux}@univ-ubs.fr>
 *  @version $Revision: 29 $
 */
public class Launcher implements IApplication, ActionListener{

    /*
     *  Public ressources -----------------------------------------------------
     *
     *  Constructors
     */
    
    /** 
     *  Launcher constructor.
     *
     *  Initialize applications collection and the panel
     */
    public Launcher() {
        engine = new LaunchEngine();
        view = new LaunchView(this, engine);
    } // ----------------------------------------------------------- Launcher()

    /*
     * Public methods
     */
    
    /* 
     *  see interface documentation
     */
    public void start(IPda pda) {
	this.pda = pda;
    } // -------------------------------------------------------------- start()

    /* 
     *  see interface documentation
     */
    public String getAppliName() {
	return name;
    } // ------------------------------------------------------- getAppliName()

    /* 
     *  see interface documentation
     */
    public JPanel getAppliPanel() {
	return view.getPanel();
    } // ------------------------------------------------------ getAppliPanel()

    /* 
     *  see interface documentation
     */
    public boolean close() {
	return true;
    } // -------------------------------------------------------------- close()

    /**
     *  Callback method, reaction to button pushed
     */
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        IApplication appli = engine.getAppli(cmd);
        System.out.println("Launch" + cmd + ":" + appli.getAppliName());
        pda.launchAppli(appli);
    } // ---------------------------------------------------- actionPerformed()
    
    /*
     * Private implementation -------------------------------------------------
     */
    
    /** Application name */
    protected String name = "Launcher";
    
    /** Back link to the PDA that supports this launcher */
    protected IPda pda;

    /** the view of the application */
    protected LaunchView view;
    
    /** the engine of the application */
    protected LaunchEngine engine;

} // ----------------------------------------------------------- Class Launcher
