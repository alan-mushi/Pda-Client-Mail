/**
 * Contains classes which manage the connection.
 */
package pdaNetwork.client.network; 
