/**
 * Contains service classes used by the client.
 */
package pdaNetwork.client.service;
