/**
 * Contains classes which have no particular package
 */
package pdaNetwork.misc;
